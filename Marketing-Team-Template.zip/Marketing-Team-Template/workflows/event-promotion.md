---
name: Event promotion package
description: Everything needed to fill an event or webinar, from plan to invitations and posts
agents: [Marcus, Chloe, Iris]
---

# Brief template

Event: {{event name}}
Date and format: {{date, in person / online}}
Audience: {{who should attend}}
Goal: {{registrations and meetings target}}
Speakers: {{speakers}}
Vendor involved: {{vendor or none}}
Language: {{Hebrew / English / both}}

Marcus builds the plan with `event-plan`. Chloe writes 2 invitation emails (`newsletter`) and 2 LinkedIn posts (`linkedin-post`). Iris reviews everything with `content-review`.
