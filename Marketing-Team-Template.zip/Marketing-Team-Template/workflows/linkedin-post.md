---
name: LinkedIn post, reviewed
description: Write a LinkedIn post and have it reviewed before it goes out
agents: [Chloe, Iris]
---

# Brief template

Profile: {{company page or person}}
Topic: {{topic}}
Goal: {{comments / registrations / clicks / awareness}}
Language: {{Hebrew / English / both}}
The one fact or story at the center: {{fact}}
Link: {{link}}

Chloe drafts with the `linkedin-post` skill and gives 3 hooks. Iris runs `content-review` and returns the clean version.
