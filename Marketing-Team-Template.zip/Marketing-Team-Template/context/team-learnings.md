# Team Learnings

Preferences and lessons that apply to every agent. Every agent reads this before starting work.
Add a dated entry whenever the owner corrects something that isn't specific to one agent.

Format:
**[YYYY-MM-DD] - [task name]**
[One or two lines: the rule to follow from now on.]

---

**[Starter] - Lessons carried over from the NBD workspace**
- Ask about length and format before writing. Default to short.
- Check what already exists in the workspace before building something new.
- Final deliverables contain no process notes, agent names or `[confirm]` tags.
- When the owner removes a point, it stays out of every later revision.
