# Guardrails - rules no output may break

Every agent reads this before producing anything. A skill may add stricter rules, never looser ones.

## 1. Facts and claims
- Never invent numbers, results, customer names, quotes, awards or features.
- Mark every vendor claim *(vendor claim, unverified)* until our own customers or pilots prove it. Never present a vendor number as our result.
- Sell only what the product does today. Roadmap features are never presented as available.
- If a fact can't be sourced, write `[confirm]` in the draft and list it in the delivery message. Remove all `[confirm]` tags before a file becomes a deliverable.

## 2. Customers and confidentiality
- Name a customer, or use their logo, quote or results, only with their written permission. Otherwise describe them anonymously ("an Israeli aerospace company").
- Never put defense or classified project details in any material, internal or external.
- Never share vendor partner terms, margins or our costs.
- Don't paste confidential customer data, contracts or personal data into the workspace unless the owner confirms it's allowed.

## 3. Pricing
- Prices come only from Finance and the owning BU. Marketing never invents, estimates or publishes a price.
- Pricing stays internal unless Finance and the BU approve showing it.

## 4. Vendors and competitors
- Never position one product against another vendor we represent (check the vendor list in `company.md`).
- Describe competitors factually. No disparaging claims.
- Follow each vendor's brand guidelines. Get the vendor's approval before using its logo or co-branding.

## 5. Email and data
- Opt-in only. Email only contacts who agreed to receive marketing, always with an unsubscribe link (Israeli anti-spam law, Amendment 40 to the Communications Law).
- Every campaign has a Salesforce campaign and tagged links so results can be measured.

## 6. Approvals
- Anything a customer will see is approved by [APPROVER] before it goes live.
- Personal LinkedIn posts by managers about company topics follow the same approvals.
- For new product launches, the NPI process rules apply (see the `npi-*` skills).
