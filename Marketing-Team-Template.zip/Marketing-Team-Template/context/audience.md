# Who we write for

> Filled in by the `setup-workspace` skill. Keep one block per audience. Agents read this before writing anything external.

## Audience 1: [e.g. R&D managers at Israeli defense and aerospace companies]
- **Their job:** [what they're measured on]
- **Their pains:** [what keeps them up at night, in their words]
- **What they already use:** [tools, vendors, in-house solutions]
- **What convinces them:** [proof, peers, demos, numbers, expert content]
- **Where they are:** [LinkedIn, events, vendor user groups, email]
- **Language:** [Hebrew / English / both]
- **Turn-offs:** [hype, generic content, pushy sales]

## Audience 2: [e.g. manufacturing and operations managers]
- **Their job:**
- **Their pains:**
- **What they already use:**
- **What convinces them:**
- **Where they are:**
- **Language:**
- **Turn-offs:**
