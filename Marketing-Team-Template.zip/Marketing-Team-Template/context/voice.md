# [OWNER_NAME]'s Voice and Style

> Filled in by the `setup-workspace` skill. Best source: 3 to 5 real samples of the owner's writing (posts, emails, a newsletter). Paste them into the chat and ask Sam to "update my voice file".
> Until then, agents use the Systematics defaults below.

## Tone
[e.g. Direct and confident. The point in the first sentence.]

Systematics default: expert, clear, confident. We sound like the engineer-friendly partner who knows the workflow, not like a vendor brochure.

## Words and phrases that fit
- [phrases the owner actually uses]
- Plain verbs: build, solve, test, launch, cut, speed up
- Concrete outcomes and numbers over adjectives

## Words and phrases to avoid
- [phrases the owner hates]
- Hype: "revolutionary", "game-changing", "cutting-edge", "seamless", "unlock"
- Corporate filler: "synergy", "leverage", "touch base", "in today's fast-paced world"
- Openers like "Excited to announce" or "I'm thrilled to share"

## Hebrew
[e.g. Natural spoken Hebrew, not translated English. Keep product names in English.]

## Formatting
[e.g. Short paragraphs, tight bullets, headline first, one call to action.]

## Real samples
[Paste 2 to 3 short examples here. Agents learn more from samples than from rules.]
