---
name: Launch LinkedIn post (example)
type: task
status: in-progress
assigned: Chloe
working: review
project: _example-product-launch
created: 2026-11-09
---

## Brief

Write a LinkedIn post for the company page announcing our new webinar on cutting prototype costs with simulation. Audience: R&D managers. Goal: registrations. English.

## Draft

## LinkedIn post: Simulation webinar
**Goal:** webinar registrations
**Channel / language:** Company page, English
---
Every physical prototype you skip is weeks you get back.

Most R&D teams we work with still build two or three prototypes before a design is signed off. Each round means parts, lab time and a schedule that slips.

On [date], our application engineers will show how teams validate earlier with simulation, and where physical testing still earns its place.

45 minutes. Real workflows. No slides about "digital transformation".

Save your seat: [link]
---
### Hook options
1. Every physical prototype you skip is weeks you get back.
2. How many prototypes did your last design need?
3. Your lab isn't the bottleneck. Your validation process is.
### Notes
- [confirm] webinar date and registration link
- Reviewed by Iris: Ready after fixes (date and link)

> Example of `working: review`: the draft is delivered and waiting for the owner to say "done" or give feedback.
