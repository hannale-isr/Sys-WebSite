---
name: Example - Product launch (delete me)
owner: [OWNER_NAME]
created: 2026-11-09
due: 2026-12-15
status: example
---

# Example - Product launch

> This is a sample project to show how projects and tasks are organized. Delete this folder once you have your own.

**Goal:** 20 demo meetings in the first 60 days after launch.
**Agents:** Felix (positioning), Chloe (content), Marcus (campaign), Iris (review), Nina (results).

## Tasks
| Task | Agent | Status |
|------|-------|--------|
| `tasks/launch-linkedin-post/brief.md` | Chloe | review |
