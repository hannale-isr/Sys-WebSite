# work/tasks

This folder fills up as you work. Agents create files here automatically.
