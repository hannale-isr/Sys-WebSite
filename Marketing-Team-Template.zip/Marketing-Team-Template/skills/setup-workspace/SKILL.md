---
name: setup-workspace
description: First-time setup of this marketing workspace. Interviews the owner and fills in company.md (Our team), context/voice.md, context/audience.md, context/guardrails.md (approver) and the owner placeholders in AGENTS.md and team files. Use when the owner says "set up my workspace", "let's start", "onboard me", or when any file still contains [OWNER_NAME] or other square-bracket placeholders.
---

# Skill: Set up the workspace

**Who runs it:** Sam.
**When:** the first session, or whenever placeholders remain.
**Time:** 15 to 20 minutes.
**Goal:** every agent knows who the owner is, what the team does, how the owner writes and who they write for.

## Rules
- Ask in small rounds (3 to 4 questions at a time), not a 20-question form.
- Offer examples with every question so the owner can answer fast.
- Never invent answers. If the owner skips something, leave the placeholder and list it at the end.
- The owner is not a developer. Edit the files yourself. Never ask them to open a terminal.

## Steps

**Round 1 - You and your team**
1. Your name and role?
2. Which BU or team are you in, and what is marketing responsible for there? (e.g. "demand gen and events for the CREATE BU")
3. Which vendors or products do you market most?
4. Who approves customer-facing content?

Write the answers into: `AGENTS.md` (owner line), `company.md` (frontmatter and "Our team"), `context/guardrails.md` ([APPROVER]), and replace `[OWNER_NAME]` in every `team/*.md` file.

**Round 2 - Goals and channels**
5. What are your team's goals this year? Numbers if you have them.
6. Which channels do you run? (LinkedIn, newsletter, website, events, webinars, vendor co-marketing)
7. Which tools do you use? (Salesforce, HubSpot, Canva, Monday)
8. What's already built that agents should reuse? (brand book, templates, past campaigns) Ask them to drop files into the workspace if they can.

Write into `company.md`, "Our team".

**Round 3 - Your voice**
9. Paste 2 to 3 things you wrote that you're proud of (a post, an email, a newsletter intro).
10. Three words for how you want to sound? Words or phrases you hate?
11. Hebrew, English, or both? Any rules for Hebrew?

Analyze the samples (sentence length, openers, tone, vocabulary, formatting) and fill in `context/voice.md`. Keep the samples in its "Real samples" section.

**Round 4 - Your audience**
12. Who are your 1 to 3 main audiences? (role, company type)
13. For each: what are they measured on, what are their pains, what convinces them, where do you reach them?

Fill in `context/audience.md`.

**Close**
14. Show a short summary of what was filled in and what is still open.
15. Suggest a first real task to test the setup (e.g. "Ask Chloe for a LinkedIn post about your next event").

## Quality checks
- [ ] No `[OWNER_NAME]`, `[OWNER_ROLE]`, `[BU_OR_TEAM]`, `[APPROVER]` left, or each remaining one is listed as open
- [ ] `context/voice.md` is based on real samples, or says clearly it's inferred
- [ ] At least one audience is filled in
- [ ] The owner knows their first task

## Done when
The files are filled in, the owner confirmed the summary, and a dated entry is in `context/team-learnings.md`: "Workspace set up."
