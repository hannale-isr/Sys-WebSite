---
name: npi-marketing-brief
description: Write the positioning and the Marketing Brief for a new product in the New Product Introduction process. Covers the working positioning drafted from the vendor's material in Stage 1 Check (1.6 The offer) before Decision 1, and the Marketing Brief (2.2 in the launch plan) written by the BU marketing lead in Stage 2 Get ready to sell. Use whenever the user wants positioning, a core message, a Marketing Brief, or "how do we talk about this product in Israel", even if they don't name the brief.
---

# Skill: Positioning and Marketing Brief

**Who uses this:** part 1 by the NBD team. Part 2 by the BU marketing lead after Decision 1.
**When:** part 1 in Stage 1 Check, before Decision 1. Part 2 in week 1 of Stage 2 Get ready to sell.
**Where it goes:** the launch plan, **1.6 The offer**, **Positioning** (part 1) and **2.2 Marketing Brief** (part 2).
**Goal:** one clear message for the right buyers in Israel, approved before any asset is built, so the product page and campaign all say the same thing.

## Rules
- Marketing can't start before Decision 1 is a go, so part 1 comes from the vendor's material, not from a marketing team.
- Only the BU marketing lead completes the positioning for Israel, and NBD approves it.
- Mark every vendor claim *(vendor claim, unverified)* until our customer conversations or pilots prove it.
- Never invent numbers, results, customer names, quotes or features.
- Name a customer, or use their logo, quote or results, only with their written permission. Otherwise describe them anonymously.
- Never put defense or classified project details in any material.
- Use only the final price approved by Finance and the owning BU, never below the approved floor. Pricing stays internal unless they approve showing it.
- Don't position the product against a vendor we already represent (check the current vendors check in 1.5 Business case). Describe competitors factually.
- Anything a customer will see needs NBD's approval before use.

## Part 1: working positioning (before Decision 1)
1. Read the vendor's go-to-market material: segments, messaging, competitor comparisons.
2. Adapt it with the market view from 1.3 Market and customers (buyer map, segments in priority order, competition in Israel).
3. Write the positioning statement:
   > For [who] who [problem], [product] by Systematics is the [category] that [key benefit], unlike [alternative], because [why us].
4. Mark what came from the vendor *(vendor view)*. This is a working version for the Decision 1 pack.

## Part 2: the Marketing Brief (Stage 2, 3 pages max)
Inputs: the working positioning, sections 1.3 to 1.6, the trial report, the pilot offer, and past BU campaigns and results.

1. **Complete the positioning for Israel.** Local segments in priority order, local competitors, wording for our customers. Take input from the launch owner. NBD approves it.
2. **Fill in every field:**
   - audience: buyers and champions
   - core message: one sentence a buyer would repeat
   - proof points, with vendor claims labeled *(unverified)*
   - channels
   - assets needed (the product page, one-pager, demo video and so on; see the product page and campaign plan skills)
   - launch moments
   - budget and vendor co-marketing (funds through the launch owner)
   - success metrics for the first 90 days: meetings, demos, pilots, conversions. Agree them with the owning BU manager.
3. **Get approval** from NBD by the end of week 1 of Stage 2, then update the "2 Get ready" row in the tracker.

## Quality checks
- [ ] The core message fits in one sentence and says why us
- [ ] Every proof point is ours, or labeled as a vendor claim
- [ ] No customer named without written permission, no defense details
- [ ] No pricing unless Finance and the BU approved showing it
- [ ] The positioning doesn't pit the product against a vendor we represent
- [ ] Hebrew and English versions make the same claims

## Done when
NBD has approved the brief and the tracker is updated. Then the product page and campaign plan can start.
