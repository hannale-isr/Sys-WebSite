---
name: npi-product-page
description: Build the product page and one-pager for a new product launch in the New Product Introduction process, in Stage 2 Get ready to sell. Use whenever the BU marketing team needs the product web page, landing page, or the Hebrew and English one-pager for a new product, after the Marketing Brief is approved, even if they just say "write the page for the new product".
---

# Skill: Product page and one-pager

**Who uses this:** the BU marketing lead's team.
**When:** weeks 2-3 of Stage 2 Get ready to sell, once NBD has approved the Marketing Brief. Not before: the page is built from the brief.
**Where it goes:** the BU's website, unpublished until launch day. Link it under **2.2 Marketing Brief** (assets needed) in the launch plan.
**Goal:** a page that tells the right buyer in a few lines what the product does for them, why Systematics, and what to do next, without claims we can't back.

## Rules
- Mark every vendor claim *(vendor claim, unverified)* until our customer conversations or pilots prove it.
- Never invent numbers, results, customer names, quotes or features.
- Name a customer, or use their logo, quote or results, only with their written permission. Otherwise describe them anonymously.
- Never put defense or classified project details in any material.
- Use only the final price approved by Finance and the owning BU, never below the approved floor. Pricing stays internal unless they approve showing it.
- Don't position the product against a vendor we already represent (check the current vendors check in 1.5 Business case). Describe competitors factually.
- Anything a customer will see needs NBD's approval before use.
- Don't start before Decision 1 is a go, and respect its conditions.

## Inputs
The approved Marketing Brief (positioning for Israel, core message, proof points), the pilot offer from 1.6 The offer, the demo video if ready, and the vendor's brand guidelines and logos from the partner portal.

## Steps
1. **Build the one-pager first** (Hebrew and English, one page each). It is the short version the page grows from: headline from the core message, who it's for, the problem, what it does, three proof points, the pilot offer, a call to action.
2. **Build the page from the one-pager**, in this order:
   1. Headline and sub-line: the core message
   2. The problem, in the buyer's words
   3. What the product does, in 3-4 outcomes (not feature lists)
   4. Proof: confirmed results first, vendor claims labeled
   5. How we work with you: the pilot, in plain terms (no price unless approved)
   6. Call to action: book a demo or start a pilot
3. **Add the vendor's logo and wording** only after the vendor approves co-branding.
4. **Add tracking:** tagged links, a form that creates a Salesforce lead with the campaign source.
5. **Get approvals:** NBD for the content, vendor if co-branded. Keep the page unpublished until launch day.
6. **Check both languages say the same thing.**

## Quality checks
- [ ] Matches the approved core message and positioning
- [ ] Every claim is ours or marked as a vendor claim
- [ ] No customer named without written permission, no defense details, no pricing unless approved
- [ ] The vendor's brand rules followed
- [ ] The form routes to Salesforce and the account owner
- [ ] Not live before launch day

## Done when
The one-pager and page exist in both languages, are approved, tracked and unpublished, and "Marketing assets and campaign ready" in 2.6 Ready to launch can be ticked once the campaign plan is also done.
