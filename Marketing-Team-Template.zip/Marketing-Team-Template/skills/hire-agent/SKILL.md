---
name: hire-agent
description: Add a new agent (team member) to the workspace when no current agent fits a recurring kind of work. Use when the owner says "hire someone for", "I need an agent for", "add a team member", or when Sam sees repeated work that no agent owns.
---

# Skill: Hire a new agent

**Who runs it:** Sam.
**Where it goes:** `team/[name].md` and the team table in `AGENTS.md`.
**Goal:** a specialist with a clear job, a personality and rules, ready to work.

## Rules
- Hire only for work that will come back. A one-off task goes to the closest existing agent.
- Don't overlap. If the role is 70% the same as an existing agent, extend that agent instead.
- Name rules from `AGENTS.md`: a first name from the list, unique, never a job title.

## Steps
1. **Make the case in 3 lines:** what work is uncovered, why no one fits, what the new agent will own. Get the owner's OK.
2. **Ask the owner 3 questions:**
   - What does great output look like? (an example if possible)
   - What should this agent never do?
   - Who does it hand work to, and who reviews it?
3. **Pick a name** from the list in `AGENTS.md` and remove it from the list.
4. **Copy** `team/_new-agent-template.md` to `team/[name-lowercase].md` and fill in every section. Write the principles as Don't / Do with real examples from this team's work.
5. **Add the agent** to the team table in `AGENTS.md` and to the routing guide in `team/sam.md`.
6. **Check skills:** if the agent needs a skill that doesn't exist, offer to create it with `create-skill`.
7. **First task:** give the agent a small real task. When the owner approves it, change `status: onboarding` to `status: active`.

## Quality checks
- [ ] No overlap with an existing agent
- [ ] Name follows the rules
- [ ] Every template section filled, no placeholders left
- [ ] Listed in `AGENTS.md` and in Sam's routing guide

## Done when
The agent is listed, has completed one approved task, and its status is `active`.
