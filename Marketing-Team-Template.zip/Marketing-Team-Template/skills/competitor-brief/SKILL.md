---
name: competitor-brief
description: Research a competitor and write a factual competitor brief or sales battlecard for the Israeli market. Use when the owner asks about a competitor, "how do we compare to X", "what is X doing", a battlecard, objection handling against a competitor, or competitive positioning.
---

# Skill: Competitor brief and battlecard

**Who uses this:** Felix.
**Where it goes:** the task file. 1 page battlecard, 2 pages max for a brief.
**Goal:** sales knows where we win, where we don't, and what to say, without a single unsupported claim.

## Rules
- Facts only, each with a source and a date. No disparaging claims.
- Separate what we know (sources) from what we believe (labeled as our view).
- Never position against a vendor we represent (check `company.md`).
- Remember the competitor may be another Israeli reseller of a different vendor, or the same vendor sold by someone else. Ask which.
- Our differentiation is often Systematics, not the product: local expertise, services, support, workflow coverage.

## Inputs
Competitor name, which of our products it competes with, the segment, any recent deal where we met them (ask the owner or sales).

## Steps
1. **Research** public sources: website, product pages, pricing pages, press, LinkedIn activity, events, job posts (they reveal priorities), review sites. Note the date of each.
2. **Ask sales** (through the owner) for field input: where we met them, why we won or lost.
3. **Write the battlecard:**

```
## [Competitor] vs. Systematics [product]
**In one line:** [who they are, who they sell to]
**Where they're strong:** [factual, sourced]
**Where we win:** [product + Systematics value, sourced]
**When we lose (be honest):**
**Questions that expose the difference:** [3 discovery questions for sales]
**Common objections and answers:** [2 to 3]
**Recent moves:** [dated]
**Sources:**
```

4. Send to Iris to check claims and tone.

## Quality checks
- [ ] Every claim has a source and a date
- [ ] "Where they're strong" is honest
- [ ] No positioning against our own vendors
- [ ] Usable by a salesperson in 2 minutes

## Done when
The owner approves it and it's shared with the relevant BU sales team.
