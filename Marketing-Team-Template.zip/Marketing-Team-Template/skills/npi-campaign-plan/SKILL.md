---
name: npi-campaign-plan
description: Write and run the launch campaign plan for a new product in the New Product Introduction process, from the approved Marketing Brief in Stage 2 Get ready to sell to day 90 of Stage 3 Launch. Use whenever the BU marketing team needs a campaign plan, content calendar, email sequence, launch-week sequence, lead handoff to sales, or the 30/60/90 marketing review for a new product launch.
---

# Skill: Campaign plan

**Who uses this:** the BU marketing lead's team.
**When:** Stage 2 Get ready to sell (about 3 weeks) to build it, launch week to run it, days 0-90 of Stage 3 Launch to measure.
**Where it goes:** under **2.2 Marketing Brief** in the launch plan. Also the **2.6 Ready to launch** checklist, **3.1 Launch**, the **3.3 Day 30, 60 and 90 reviews** and the tracker.
**Feeds:** the campaign plan (channels, campaign and lead handoff) feeds the **2.3 Go-to-market** review, which the BU sales manager presents at the end of week 2.
**Goal:** the right buyers in the target segments hear about the product at launch, and sales receives qualified meetings it can turn into pilots.

## Rules
- Mark every vendor claim *(vendor claim, unverified)* until our customer conversations or pilots prove it.
- Never invent numbers, results, customer names, quotes or features.
- Name a customer, or use their logo, quote or results, only with their written permission. Otherwise describe them anonymously.
- Never put defense or classified project details in any material.
- Use only the final price approved by Finance and the owning BU, never below the approved floor. Pricing stays internal unless they approve showing it.
- Anything a customer will see needs NBD's approval before use.
- Commercial questions to the vendor go through the launch owner until Decision 2 (handover), then through the BU manager. Technical questions go through NBD (Roni).
- Don't start before Decision 1 is a go, and respect its conditions.

## Inputs
The approved Marketing Brief, target segments and pilot candidates (1.3 Market and customers), Salesforce lists (ask the BU sales manager), the vendor's co-marketing funds, and results of past BU campaigns.

## Steps
1. **Write the plan** under 2.2 Marketing Brief:
   - audiences: the segments from 1.3, each with a Salesforce list of contacts who agreed to receive marketing
   - channels and a dated calendar from pre-launch to day 90
   - budget, including vendor co-marketing funds
   - an owner on every item
2. **Agree co-marketing with the vendor** in Stage 2, through the launch owner: funds, a joint announcement, logo use, a joint webinar or event.
3. **Set up tracking:** a Salesforce campaign, tagged links for every channel, lead routing to the account owner.
4. **Build the remaining assets** from the brief (email sequence of 3, social posts, webinar deck, pilot offer sheet). NBD approves anything customer-facing, the vendor anything co-branded. The product page has its own skill.
5. **Launch week (3.1), in this order:** internal announcement (the BU manager leads), product page, first email, social posts, vendor co-announcement, event invitations.
6. **Hand leads to sales daily.** Every lead goes into Salesforce with its campaign source, and the account owner follows up within one working day.
7. **Measure.** Bring leads, meetings and pilots sourced to the weekly launch huddle, which the BU manager leads after the handover. Fill in the 3.3 reviews at day 30, 60 and 90 against the brief's 90-day metrics. Change channels and assets, not the positioning.
8. **Case study:** build it from the first successful pilot, with the customer's written permission.

**Marketing rules:**
- Opt-in only: email only to contacts who agreed, with an unsubscribe link, as Israeli law requires.
- Nothing goes live before launch day.
- Follow the vendor's brand guidelines and get approval before using its logo.
- One message in Hebrew and English.
- No public message that pits the product against a vendor we represent.
- Personal posts by managers follow the same approvals.

## Quality checks
- [ ] Every audience has a list and a channel
- [ ] Every calendar item has an owner and a date
- [ ] Tracking is in place and leads route to Salesforce
- [ ] Approved by NBD, and by the vendor if co-branded
- [ ] Claims are ours or marked as vendor claims

## Done when
The campaign ran to day 90, the 30/60/90 marketing reviews are filled in, the case study is published or scheduled, and the lessons are handed to the BU manager for the day-90 review.
