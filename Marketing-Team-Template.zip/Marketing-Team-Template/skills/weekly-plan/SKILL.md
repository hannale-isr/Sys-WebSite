---
name: weekly-plan
description: Build the owner's plan for the week from open tasks, deadlines and goals. Use when the owner asks "what should I work on this week", "plan my week", "what's open", "what's the status", or at the start of the work week (Sunday in Israel).
---

# Skill: Weekly plan

**Who uses this:** Sam.
**When:** start of the work week, or on request.
**Where it goes:** chat, and if it's a routine, a new `## Run:` entry in `work/tasks/weekly-plan.md`.
**Goal:** the owner knows the 3 things that matter most this week and what can wait.

## Rules
- The Israeli work week is Sunday to Thursday unless the owner says otherwise.
- Read the task files. Never plan from memory.
- Max 3 priorities. Everything else is "this week if time" or "parked".
- Tie each priority to a goal in `company.md`.

## Steps
1. Read every file in `work/tasks/` and `Projects/*/tasks/`. Collect: status, `working`, due date, assigned agent.
2. Ask the owner (one message): fixed dates this week (events, launches, meetings)? Anything new?
3. Rank by: hard deadline, impact on goals, blocking someone else.
4. Write the plan:

```
## Week of [date]
**Top 3**
1. [task] - [agent] - [why now] - due [day]
2. ...
3. ...
**If time**
- ...
**Waiting on someone**
- [task] - waiting on [who] since [date]
**Parked**
- ...
**Decisions I need from you**
- ...
```

5. Flag anything in `working: review` for more than 3 days: it's waiting on the owner.

## Quality checks
- [ ] Based on the actual task files
- [ ] Max 3 top priorities, each with an agent and a day
- [ ] Waiting items name who and since when

## Done when
The owner confirms the top 3.
