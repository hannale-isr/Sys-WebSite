---
name: content-review
description: Review any piece of marketing content before it goes out, checking guardrails, claims, brand voice, clarity and Hebrew/English consistency, and return a verdict with fixes and a clean version. Use when the owner says "check this", "review this", "is this ready", "proofread", pastes a draft, or before any customer-facing piece is delivered as final.
---

# Skill: Content review

**Who uses this:** Iris.
**Goal:** a clear verdict, every issue with a fix, and a clean version ready to use.

## Rules
- Blockers are non-negotiable. A piece with a blocker is "Not ready".
- Every issue: quote the line, say why, give the rewrite.
- Don't rewrite what isn't broken.

## Steps
1. **Understand the piece:** channel, audience, goal, language. Ask if unclear.
2. **Guardrails pass** (`context/guardrails.md`), line by line. Each of these is a **Blocker**:
   - [ ] Invented or unsourced number, result, quote, customer or feature
   - [ ] Customer named, logo or quote used without written permission
   - [ ] Vendor claim not labeled
   - [ ] Roadmap feature presented as available
   - [ ] Price shown without approval
   - [ ] Defense or classified detail
   - [ ] Positioning against a vendor we represent, or disparaging a competitor
   - [ ] Email without opt-in or unsubscribe
3. **Voice pass** (`context/voice.md`), each a **Fix**:
   - [ ] First line makes the point
   - [ ] Banned words and hype removed
   - [ ] Sounds like the owner, expert not salesy
   - [ ] One clear CTA
4. **Clarity pass:** would a skeptical engineer get it in 10 seconds? Jargon the audience wouldn't use? Sentences over 25 words?
5. **Language pass:** typos, grammar, Hebrew reads natively, Hebrew and English versions make the same claims and offer.
6. **Write the review** in the format from `team/iris.md`: verdict, blockers, fixes, polish, clean version.
7. If the same issue appears for the third time across reviews, add it to `context/team-learnings.md`.

## Done when
The verdict is "Ready" and the clean version is in the task file.
