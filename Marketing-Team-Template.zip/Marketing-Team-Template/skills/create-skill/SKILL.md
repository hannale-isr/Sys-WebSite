---
name: create-skill
description: Create a new skill (a reusable step-by-step procedure) from a task the owner does repeatedly. Use when the owner says "turn this into a skill", "save this as a process", "I do this every month", or when the same type of task has come up three times with no matching skill.
---

# Skill: Create a new skill

**Who runs it:** Sam, with the agent who does the work.
**When:** after the same kind of task has been done 2 to 3 times, ideally right after one that went well.
**Where it goes:** `skills/[skill-name]/SKILL.md`, plus a row in `skills/README.md`.
**Goal:** next time, the agent produces the right output on the first try.

## Rules
- One skill = one deliverable. "LinkedIn event post" is a skill. "All social media" is not.
- Build from real examples. The best input is a past output the owner approved, plus the corrections they made on the way.
- Short. A skill over 80 lines is usually two skills.
- Use the owner's words for the trigger, so the agent recognizes the request.

## Steps
1. **Ask the owner 3 questions:**
   - What does this task produce, and who uses it?
   - Which past version was the best? (find it in `deliverables/`)
   - What did you have to correct last time?
2. **Read** the approved past outputs and their task files (the feedback rounds are gold).
3. **Write the skill** using this structure:

```
---
name: [kebab-case-name]
description: [What it produces. Use when the owner says "...", "...", or asks for ...]
---

# Skill: [Name]

**Who uses this:** [agent]
**When:** [trigger or timing]
**Where it goes:** [file, channel, format]
**Goal:** [one sentence]

## Rules
- [the corrections from past rounds, written as rules]
- [relevant guardrails]

## Inputs
[what the agent needs before starting]

## Steps
1. ...

## Quality checks
- [ ] ...

## Done when
[clear finish line]
```

4. **Add a row** to `skills/README.md` and, if it fits, to the agent's routing in `team/sam.md`.
5. **Test it:** run the skill on a real or recent request and show the owner the result.

## Quality checks
- [ ] The description includes the words the owner actually uses
- [ ] Every past correction appears as a rule
- [ ] Steps are concrete enough that a new agent could follow them
- [ ] It has a clear "done when"

## Done when
The skill is saved, listed in `skills/README.md`, and tested once with the owner's approval.
