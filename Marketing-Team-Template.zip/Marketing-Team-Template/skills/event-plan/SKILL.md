---
name: event-plan
description: Plan an event, webinar, seminar, user day, workshop or trade-show presence, from goal to follow-up. Use when the owner asks to plan an event or webinar, build an event run-of-show, an invitation sequence, a registration push, or post-event follow-up.
---

# Skill: Event and webinar plan

**Who uses this:** Marcus. Chloe writes the invitations and posts, Nina reports.
**Where it goes:** the task file, as a checklist the team works from.
**Goal:** the right people show up, and every attendee gets a relevant follow-up within 2 working days.

## Rules
- Goal first: meetings booked, pipeline, or awareness? It changes everything.
- Invite only opted-in contacts by email. Personal invites from account managers to their own customers work best.
- Vendor speakers and logos need vendor approval.
- No customer speaker or logo without written permission.
- Follow-up is planned before the event, not after.

## Inputs
Event type, date, format (in person / online / hybrid), topic, audience, speakers, budget, vendor involvement.

## Steps
1. **Goal and target:** registrations, attendance, meetings booked after. Typical online attendance is 35 to 50% of registrations; plan invitations accordingly.
2. **The promise:** one sentence on what attendees will walk away with. This drives every invitation.
3. **Timeline backwards from the date:**
   - T-6 weeks: speakers, venue or platform, landing page, Salesforce campaign
   - T-4 weeks: invitation email 1, LinkedIn post, personal invites from account managers
   - T-2 weeks: invitation email 2, speaker post
   - T-3 days: reminder + calendar invite
   - T-1 day: reminder
   - Event day: run of show, who greets, who takes questions, who notes hot leads
   - T+1 day: thank-you with recording or slides, one CTA
   - T+2 days: sales follow-up on hot leads
   - T+30 days: Nina's results report
4. **Run of show:** minute-by-minute with owners.
5. **Lead capture:** how attendees are marked in Salesforce and routed to account owners.
6. **Budget:** venue, catering, promotion, vendor share.

## Quality checks
- [ ] Goal with numbers
- [ ] One-sentence promise
- [ ] Every timeline item has an owner
- [ ] Follow-up planned and assigned before the event
- [ ] Approvals for vendor and customer participation

## Done when
The event ran, follow-ups were sent, and Nina's report is filed.
