---
name: case-study
description: Write a customer case study or success story, from interview questions to the final page, in Hebrew or English. Use when the owner asks for a case study, customer story, success story, testimonial, or reference story, or has notes or a transcript from a customer conversation.
---

# Skill: Case study

**Who uses this:** Felix plans and interviews, Chloe writes, Iris reviews.
**Where it goes:** the task file, then the website, a PDF, or a sales deck.
**Goal:** a story another engineer recognizes as their own problem, with a result they believe.

## Rules
- **Written permission from the customer before anything is drafted for publication.** Without it, the story is anonymous ("an Israeli medical device company") and has no logo.
- The customer approves the final text before it's published.
- Never put defense or classified details in, even if the customer agrees verbally.
- Results are the customer's words or measured numbers, never our estimate.
- Vendor co-branding needs vendor approval.

## Inputs
Customer, products and services involved, the account manager, permission status, any measured results.

## Steps
1. **Check permission** and record its status in the task file.
2. **Prepare the interview** (30 minutes, with the customer's project lead):
   - What were you trying to do, and what stood in the way?
   - How did you handle it before? What did that cost (time, money, risk)?
   - Why did you choose this approach, and why Systematics?
   - What did the implementation look like? What did our team do?
   - What changed? Any numbers?
   - What would you tell a peer considering it?
3. **Write the story (400 to 600 words):**
   - Headline: the result, in the customer's terms
   - The customer in 2 lines
   - The challenge
   - The solution: product + what Systematics did (services, training, support)
   - The results: numbers or concrete changes
   - A quote (approved)
   - CTA
4. **Make a short version** (80 words) for LinkedIn and sales decks.
5. Iris reviews, then the customer approves.

## Quality checks
- [ ] Written permission recorded
- [ ] Results are the customer's, not ours
- [ ] Systematics' role is clear, not only the product
- [ ] Customer approved the final text

## Done when
The customer approved and the story is published or handed to sales.
