---
name: linkedin-post
description: Write a LinkedIn post for the Systematics company page, a BU page, or a manager's personal profile, in Hebrew or English. Use when the owner asks for a LinkedIn post, a social post, an event or webinar promo post, a product or partnership announcement, or "something for LinkedIn".
---

# Skill: LinkedIn post

**Who uses this:** Chloe. Iris reviews.
**Where it goes:** the task file, then the owner posts it.
**Goal:** a post a busy engineer stops for, reads to the end, and acts on.

## Rules
- All guardrails apply (`context/guardrails.md`): no invented facts, no customer names without written permission, vendor claims labeled, no defense details.
- No "excited to announce", no hashtag walls (max 3), no emoji in every line.
- Personal posts by managers follow the same approvals as company posts.
- Tag a vendor or partner only if they approved it.

## Inputs
Ask if missing: **whose profile** (company page or a person), **goal** (awareness, registrations, comments, clicks), **language**, **the one fact or story** at the center, link if any.

## Steps
1. **Pick the angle** (one): a number, a customer problem (anonymous unless approved), a lesson learned, a contrarian take, behind the scenes, an event or offer.
2. **Write 3 hook options.** The hook is the first line, under 12 words, and makes sense on its own before "see more".
3. **Write the body:**
   - Line 2 to 3: why it matters to the reader
   - The concrete detail
   - The wider point
   - One CTA (comment, register, DM, click)
4. **Format:** one or two sentences per paragraph, white space, 80 to 200 words for most posts. Link in the post only if the goal is clicks.
5. **Hebrew:** write natively, keep product names in English, right-to-left friendly (no lines starting with English words if avoidable).
6. Send to Iris (`content-review`) before delivering as final.

## Post formats that work for our buyers
- **The workflow insight:** "Most [role]s still do [X]. Here's what it costs." + one fix
- **The event post:** the one thing attendees will learn, not the agenda
- **The partner post:** what changes for the customer, not "we're proud to partner"
- **The people post:** an application engineer's expertise, in their words

## Quality checks
- [ ] Hook works alone, under 12 words
- [ ] One concrete detail
- [ ] Exactly one CTA
- [ ] Sounds like the profile owner, not a brochure
- [ ] Guardrails passed, reviewed by Iris

## Done when
The owner approves the final text.
