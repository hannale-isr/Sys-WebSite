---
name: campaign-brief
description: Plan a marketing campaign that is not a new product launch, such as a demand-gen push, a vendor promotion, a maintenance renewal campaign, a training-course campaign or an awareness campaign. Use when the owner asks to plan a campaign, a promotion, a quarter's marketing, or "how do we get more leads for X". For new product launches use npi-campaign-plan.
---

# Skill: Campaign brief

**Who uses this:** Marcus, with Felix for the message and Nina for the measurement.
**Where it goes:** the task file, 2 pages max.
**Goal:** a plan the team can run on Monday, with a number to hit.

## Rules
- No measurable goal, no plan. Ask for the number.
- Every audience has a real opted-in Salesforce list and an owner.
- Every calendar item has an owner and a date.
- Tracking is set up before the first send.
- Check vendor co-marketing funds and assets before building from scratch.

## Inputs
Goal and date, product or offer, audience, budget, what ran before and how it did (ask Nina), vendor assets.

## Steps
1. **Goal:** one number and a date (e.g. "25 demo meetings for Tulip by March 31").
2. **Audience:** 1 to 3 segments, each with list source, size and owner.
3. **Message:** one sentence. Use Felix's positioning if it exists. Plus one offer (demo, assessment, webinar, trial).
4. **Channels:** pick the 2 to 3 that reach this audience. Say why.
5. **Calendar:** work backwards from the key date. Table with date, item, channel, owner, status.
6. **Budget:** by item, including vendor funds.
7. **Tracking:** Salesforce campaign name, tagged links, lead routing.
8. **Sales follow-up rule:** who follows up, within how long, with what.
9. **Measurement:** what Nina reports and when (e.g. weekly leads, day-30 review).

Use the output format in `team/marcus.md`.

## Quality checks
- [ ] One goal number with a date
- [ ] Each audience has a list and an owner
- [ ] Each item has an owner and a date
- [ ] Tracking and follow-up rule defined
- [ ] Fits in 2 pages

## Done when
The owner approves the brief and the first calendar items are assigned.
