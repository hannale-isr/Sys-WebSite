# Skills - which one for which task

A skill is a step-by-step procedure for one kind of recurring work. Agents check this list before every task and follow the matching skill.

## Workspace skills

| Task | Skill | Agent |
|------|-------|-------|
| First-time setup: fill in company, voice, audience | `setup-workspace` | Sam |
| Plan my week / what should I focus on | `weekly-plan` | Sam |
| Add a new agent to the team | `hire-agent` | Sam |
| Turn a repeated task into a new skill | `create-skill` | Sam |

## Marketing skills

| Task | Skill | Agent |
|------|-------|-------|
| LinkedIn post (company page or personal) | `linkedin-post` | Chloe |
| Email newsletter or single marketing email | `newsletter` | Chloe |
| Plan a campaign (non-launch) | `campaign-brief` | Marcus |
| Plan an event, webinar or seminar | `event-plan` | Marcus |
| Competitor brief or battlecard | `competitor-brief` | Felix |
| Customer case study | `case-study` | Felix, then Chloe |
| Campaign or monthly performance report | `performance-report` | Nina |
| Review anything before it goes out | `content-review` | Iris |

## New Product Introduction (company process)

Marketing's part of launching a new product starts after **Decision 1 (go)**. The process document and launch plan template are owned by NBD. Ask NBD for the "Start here" folder.

| Stage | Task | Skill | Agent |
|-------|------|-------|-------|
| 2 Get ready (2.2) | Marketing Brief and positioning for Israel | `npi-marketing-brief` | Felix |
| 2 Get ready (2.2) | Product page and one-pager | `npi-product-page` | Felix, Chloe |
| 2 Get ready, 3 Launch | Campaign plan, launch week, 90-day measurement | `npi-campaign-plan` | Marcus, Nina |

## Adding your own

When you do the same kind of task for the third time, say: **"Turn this into a skill."** Sam runs `create-skill`, saves it in `skills/[name]/SKILL.md`, and adds a row here.
