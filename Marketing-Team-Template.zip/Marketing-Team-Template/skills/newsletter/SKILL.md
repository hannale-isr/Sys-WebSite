---
name: newsletter
description: Write an email newsletter or a single marketing email (invitation, announcement, follow-up) in Hebrew or English. Use when the owner asks for a newsletter, an email blast, an event invitation email, a follow-up email after an event, or subject lines.
---

# Skill: Newsletter and marketing email

**Who uses this:** Chloe. Iris reviews.
**Where it goes:** the task file, then the owner's email tool.
**Goal:** opened, read in under a minute, one click.

## Rules
- Opt-in lists only. Every email has an unsubscribe link (Israeli anti-spam law).
- One email, one main CTA. A newsletter may have up to 3 items, but one leads.
- All guardrails apply.
- Every link is tagged so Nina can measure it.

## Inputs
Ask if missing: **audience and list**, **goal**, **the items or the offer**, **language**, **send date**, **sender** (company or a person; personal sender usually opens better).

## Steps
1. **Subject line:** write 3 options, under 45 characters, specific. Add a preview line (under 90 characters) that adds information, not "view in browser".
2. **Opening line:** the reason to keep reading. No "Dear customer, we hope this finds you well".
3. **Body:**
   - Single email: problem, what we offer, proof, CTA. Under 150 words.
   - Newsletter: lead item (3 to 4 lines + CTA), then up to 2 short items (1 to 2 lines + link each).
4. **CTA:** a button with a verb ("Save my seat", "Book a demo"), repeated once at the end in long emails.
5. **Sign-off** from a real person with a name and role.
6. **Plain-text check:** it still works if images don't load.
7. Send to Iris before delivering as final.

## Quality checks
- [ ] 3 subject lines + preview line
- [ ] First line gives a reason to read
- [ ] One leading CTA, links tagged
- [ ] Unsubscribe link noted
- [ ] Hebrew and English versions match

## Done when
The owner approves the copy and the subject line.
