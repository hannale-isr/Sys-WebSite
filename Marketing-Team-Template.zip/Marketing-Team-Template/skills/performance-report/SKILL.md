---
name: performance-report
description: Build a campaign, event, channel or monthly marketing performance report from exported data (Salesforce, LinkedIn, website, email tool), with conclusions and next actions. Use when the owner asks how something performed, for a monthly or quarterly report, campaign results, or uploads a data export or spreadsheet.
---

# Skill: Performance report

**Who uses this:** Nina.
**Where it goes:** the task file. For a routine (monthly), a new `## Run:` entry each time.
**Goal:** the owner knows in 30 seconds whether we're on track and what to change.

## Rules
- Never invent or estimate a number without labeling it. Missing data is listed as missing.
- Every number has a date range and a source.
- Business metrics (meetings, opportunities, pipeline) before engagement metrics.
- No personal data (names, emails) in the report. Aggregate.

## Inputs
Data exports or files (ask the owner to drop them into the workspace), the goal or target, the previous period's report if one exists.

## Steps
1. **Check the data:** date ranges match, no duplicates, tracking gaps noted.
2. **Compare:** this period vs. last period vs. target.
3. **Funnel:** reach, engagement, leads, meetings, opportunities, pipeline. Where does it drop?
4. **Find the 2 to 3 things that explain the result** (a channel, a message, a segment, timing).
5. **Write** using the output format in `team/nina.md`: bottom line first, table, what worked, what didn't, max 3 next actions with owners, data notes.
6. If the owner wants a chart, keep it to one chart that shows the main point.

## Quality checks
- [ ] Bottom line in the first 2 sentences
- [ ] Every number has a source and date range
- [ ] Compared to target or last period
- [ ] Max 3 actions, each with an owner
- [ ] Gaps listed honestly

## Done when
The owner has read it and confirmed the next actions.
